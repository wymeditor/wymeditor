#!perl -w
use Gimp::ScriptFu::Client;
(error (string-append "Success\n2+2=" (number->string (let ((x 2)(y 2))(+ {"x"} {"y"})))))
