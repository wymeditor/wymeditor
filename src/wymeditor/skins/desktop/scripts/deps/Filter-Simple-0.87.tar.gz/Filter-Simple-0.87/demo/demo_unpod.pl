use DemoUnPod;

$x = 'x';
$y = $x;

=pod

=head1 Example

This is a useless example

=cut

print "$y\n";
